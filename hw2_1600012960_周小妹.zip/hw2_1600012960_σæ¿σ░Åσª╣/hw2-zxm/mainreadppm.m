imreadppm('greens.ppm');

